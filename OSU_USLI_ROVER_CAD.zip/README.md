# Payload-CAD
The CAD files for OSU's USLI Rover Payload
